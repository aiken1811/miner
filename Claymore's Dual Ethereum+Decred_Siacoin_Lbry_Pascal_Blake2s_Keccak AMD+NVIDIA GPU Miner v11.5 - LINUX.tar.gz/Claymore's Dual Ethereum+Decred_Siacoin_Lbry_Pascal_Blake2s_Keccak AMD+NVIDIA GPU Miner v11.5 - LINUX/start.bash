export GPU_FORCE_64BIT_PTR 0
export GPU_MAX_HEAP_SIZE 100
export GPU_USE_SYNC_OBJECTS 1
export GPU_MAX_ALLOC_PERCENT 100
export GPU_SINGLE_ALLOC_PERCENT 100
./ethdcrminer64 -epool etc-asia1.nanopool.org:19999 -ewal 0xfe4e00aa52657cc970c262337135fa67b5737639.LUCKY-1/aiken.banks@gmail.com -epsw x -dcoin pasc -dpool pasc-asia1.nanopool.org:15555 -dwal 86646.234a8b604dad8ab9.LUCKY-1/aiken.banks@gmail.com -dpsw x -ftime 10